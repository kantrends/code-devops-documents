# Space for GitHub Copilot

- Troubleshooting [docs](./troubleshooting.md) for common issues in copilot
- Read about [copilot indexing](./copilot-indexing.md)
- Steps to assign work to Copilot Agent can be found [here](./copilot-tasks.md)
