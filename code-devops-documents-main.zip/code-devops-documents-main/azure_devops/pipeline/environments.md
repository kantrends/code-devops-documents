# Environments


# Reference
- Official Microsoft Document on [Environments](https://docs.microsoft.com/en-us/azure/devops/pipelines/process/environments?view=azure-devops)