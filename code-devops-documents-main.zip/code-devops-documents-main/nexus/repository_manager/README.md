# Welcome to Sonatype Nexus Repository Manager Arena

- Configure [Nexus in Local](./nexus_in_local.md) workstation so your application libraries are pulled from Nexus Repository Manager.
