# Other DevOps Documents
You will find all other DevOps related documents here.

- IntelliJ IDE and JetBrains License server [document](https://dev.azure.com/premierinc/PINC/_wiki/wikis/PINC.wiki/10113/JetBrains-License-Vault-IntelliJ-Activation). 
- Generate Premier [SSL Certificate](./ssl-certificate.md)
- Elastic stack (Elasticsearch, Kibana) [deployment in ECE](./ece-setup.md)

